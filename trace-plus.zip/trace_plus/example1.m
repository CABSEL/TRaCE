%An example of calculating upper and lower bounds using TraCE+ from
%single-gene KO data. 

n=100; %number of genes
num_replicate=10; %number of replicates for WT
num_multiko_replicates=10; %number of replicates for multi KO
num_it=100; %number of single gene KO experiments

data_matrix=zeros(num_it,n,num_replicate); %initialize empty data matrix
ko_corr=zeros(num_it,n,num_replicate); %initialize empty correlation matrix

%TraCE+ parameters
z_threshold=2.0;
z_cutoff=3.0;
w_cut=0.3;


net=5;

%Data files
file_part1=strcat('./sko_data/Net',num2str(net),'/replicate'); %replicates folders
file_part2=strcat('/insilico_size100_',num2str(net),'_knockouts.tsv'); %KO data files
%In the single-gene KO data files the columns represent genes and the rows
%represent KO experiments.
%First line contains the name of the genes
%Second line contains the expression level of the genes when gene number 1
%is kncoked out, line number k contains the expression level of the genes
%when gene number k-1 is knocked out

%Read data

for rep=1:num_replicate
    file=strcat(file_part1,num2str(rep),file_part2);
    dat=importdata(file,'\t', 1);
    data_matrix(:,:,rep)=dat.data;
    ko_corr(:,:,rep)=conditional_correlation_ko(dat.data);
    clear dat
end
ko_corr=mean(ko_corr,3);

%Calculate bounds
[z_matrix,gu]=trace_gu(data_matrix,z_threshold,z_cutoff); %obtain upper bound from data
[gl,uncer]=trace_gl(ko_corr,gu,w_cut); %obtain lower bound from data


%Result Analysis 
gold_file=strcat('./sko_data/Net',num2str(net),...
    '/replicate1/insilico_size100_',num2str(net),'_goldstandard_signed.tsv');
adj=read_gold_signed(n,gold_file); %adjacency matrix of true network 

TPR=nnz(((gu==adj).*(gl==adj)).*(gu~=0).*(gl~=0).*(adj~=0))/nnz(adj);
TD=  nnz((gu~=adj)+(gl~=adj)+(gu~=gl))/nnz(adj);
JD_GU=jaccard_distance(gu,adj);
JD_GL=jaccard_distance(gl,adj);

display([TPR TD JD_GU JD_GL]) %results




