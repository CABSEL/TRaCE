function B=array2string(A,n)
%converts a list of gene KO indices into a binary matrix
% Inputs:
% A=list of gene KO indices
% n=number of genes
% Outputs:
% B= binray matrix with n columns where the element (i,j) is 1 if the index
% j is listed on i-th row of A
%For example:
% A=[2,0;1,0;1,3] and
% n=3
%will result in
%B=[0 1 0
%   1 0 0
%   1 0 1]  
    

% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.

B=false(size(A,1),n);

for i=1:size(A,1)
    line=false(1,n);
    line(setdiff(A(i,:),0))=1;
    B(i,:)=line;
end


