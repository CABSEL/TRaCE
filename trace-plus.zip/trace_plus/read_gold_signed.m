function adj=read_gold_signed(n,filename)
%This function reads a signed gold standard network file in GeneNetWeaver
%format.
%Inputs:
%n=number of genes
%filename=name of the file
%Output:
%adj= the signed adjacency matrix

% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.


fid=fopen(filename); %Open file

adj=zeros(n);
tline = 'll'; %Read First Line
while ischar(tline)  %Continue till end
    tline = fgetl(fid);
    
    try
        x1=tline;
        if ischar(x1)
            x1=strrep(x1, '->', ' ');
            
            x1=strrep(x1, 'G', ' ');
            
            
            x1=strrep(x1, '"', ' ');
            connect = sscanf(x1, '%d');
            if x1(end)=='-'
                val=-1;
            elseif x1(end)=='+'
                val=+1;
            else
                val=0;
            end
        end
    catch exception
        break
    end
    
    
    adj(connect(1),connect(2))=val;
    
end
return