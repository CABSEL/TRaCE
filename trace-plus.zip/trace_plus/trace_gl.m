function [gl,uncertains]=trace_gl(corr,gu,w_cut)

%This function performs TRaCE+ to calculate lower bound and uncertain edges 
%
%Inputs:
%gu=signed upper bound. Element (i,j) of this matrix is:
%   1 if the upper bound contains a positive regulatory edge from gene i to
%   gene j, -1 if the upper bound contains a negative regulatory edge from
%   gene i to gene j, 0 if the upper bound contains no regulatory edge from
%   gene i to gene j
%corr=correlation matrix
%w_cut=cut off value for weight
%
%Outputs:
%gl=signed lower bound. Element (i,j) of this matrix is:
%  1 if the lower bound contains a positive regulatory edge from gene i to
%  gene j, -1 if the lower bound contains a negative regulatory edge from
%  gene i to gene j, 0 if the lower bound contains no regulatory edge from
%  gene i to gene j
%uncertains=set of uncertain edges


% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.

n=size(gu,1);
gl=gu;
uncertains=zeros(size(gl));

for i=1:n
    for j=1:n
        if i~=j
            for k=1:n
                if k~=i && k~=j
                    if gu(i,k)~=0 && gu(k,j)~=0
                        
                        if sign(gu(i,k))*sign(gu(k,j))==sign(gu(i,j))
                            if abs(corr(i,k))*abs(corr(k,j))>w_cut*abs(corr(i,j))
                                gl(i,j)=0;
                                uncertains(i,j)=gu(i,j);
                            end
                            
                        end
                    end
                end
            end
        end
    end
end

end