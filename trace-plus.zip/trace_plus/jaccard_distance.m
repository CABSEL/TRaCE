function jd=jaccard_distance(a,b)

%This function returns jd, the jaccard distance between the graphs a and b


% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.

jd= nnz((a~=b))/(nnz((a~=b))+nnz((a==b).*(a.*b~=0)));


end