function C=check_equal_row(A,B)

%This function returns C the indices of rows of matrix A taht are equal to
%the vector B. B and A are binary matrices.


% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.

bs=repmat(B,size(A,1),1);
C=find(sum(abs(bs-A),2)==0);
end