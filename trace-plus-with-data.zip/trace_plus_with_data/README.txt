Date: 12 Feb 2016

TRaCE+ subroutines were written for MATLAB 2011a. 

TRaCE+ has also been successfully tested on MATLAB 2014b 



trace_plus.zip should contain the following files:

1.	 adj2acc.m: MATLAB subroutine for calculating accessibility matrix from adjacency matrix

2. 	 array2string.m: MATLAB subroutine for converting a matrix of sets into a binary matrix 

3. 	 check_equal_row:  MATLAB subroutine for finding the indices of the rows in a matrix A that equal vector B

4. 	 check_subset:  MATLAB subroutine for finding the indices of the rows in matrix A which are supersets of vector B

5.	 conditional_correlation_ko.m: MATLAB subroutine for calculating conditional correlation from single-gene KO experiments

6.	 example1.m: a MATLAB script demonstrating the calculation of the upper and lower bounds from single-gene KO data using TRaCE+

7. 	 example2.m: a MATLAB script demonstrating the bounds updated using multiple KO experiments

8.	 jaccard_distance.m: MATLAB subroutine for calculating Jaccard distance between two graphs

9.	 mult_ko.tsv: an input file listing multiple KO experiments. Each line contains the indices of deleted genes.

10.  mult_ko_files.tsv: an input file listing the files containing data from multiple KO experiments. Line number k in this file must have the name of the file containing expression data from the KO experiment in line number k of the file mult_ko.tsv

11.	 net5_g17_64ko.tsv: a data file containing 10 replicates of simulated expression data from Network 5 of DREAM4 100-gene network inference challenge where genes number 17 and 64 have been deleted

12.	 net5_g22_64ko.tsv: a data file containing 10 replicates of simulated expression data from Network 5 of DREAM4 100-gene network inference challenge where genes number 22 and 64 have been deleted

13.	 net5_g64ko.tsv: a data file containing 10 replicates of simulated expression data from Network 5 of DREAM4 100-gene network inference challenge where gene number 64 has been deleted

14.	 read_gold_signed.m: MATLAB subroutine for reading a signed gold standard network file from GeneNetWeaver

15.  README.txt: this file

16.	 remove_diagonal.m: MATLAB subroutine for removing the diagonal of the input matrix  and replace it with zeros.

17.	 sep_list_bound_cycle.m: MATLAB function for obtaining the edge separatoids of the uncertain edges from GU, GL, and acc (initial upper bound). This function returns the separatoids from intersection of descendants of i in acc and parents of j in GU.

18.  sep_list_bound_cycle_acc.m: MATLAB function for obtaining the edge separatoids for the uncertain edges from GU, GL, and acc. This function returns the separatoids from intersection  of descendants of i in acc and ancestors of j in acc.

19.  sep_list_bound_cycle_bu.m: MATLAB function for obtain the separatoids for the uncertain edges from GU, GL, and acc. This function returns the separatoids from intersection of children of i in GU and ancestors of j in acc. 

20.  trace_gl.m: MATLAB subroutine for producing signed digraph lower bound of the ensemble from upper bound

21.  trace_gu: MATLAB subroutine for estimating initial signed digraph upper bound of the ensemble from single-gene KO expression data

22.	 update_bounds.m: MATLAB subroutine for ensemble bounds update 

23.	 sko_data folder containing 10 replicates of single gene KO data for networks 1-5 of DREAM4 100-gene network inference challenge.



Instruction:

0. Install MATLAB 

1. Unzip the contents of trace_plus.zip to a folder.

2. Edit example1.m to run TRaCE+ on a particular dataset. 

3. Run example1 on MATLAB to produce upper and lower bounds from single-gene KO experiments. The true positive rate, total distance, and Jaccard distances of the bounds will also be calculated.

4. Run example2 on MATLAB to produce upper and lower bounds of the ensemble for Network 5 from DREAM 4 100-gene network inference challenge. Additionally, the script will perform ensemble bounds update using data from multiple KO experiments. The true positive rate, total distance, and Jaccard distances of the bounds will also be calculated.

