function [gu,gl]= update_bounds(gu,gl,acc,expt,alpha, mult_ko_data_files)


%This function updattes upper and lower bounds baased on multiple KO
%experiments.
%Inputs:
%gu=signed upper bound. Element (i,j) of this matrix is:
%   1 if the upper bound contains a positive regulatory edge from gene i to
%   gene j, -1 if the upper bound contains a negative regulatory edge from
%   gene i to gene j, 0 if the upper bound contains no regulatory edge from
%   gene i to gene j
%gl=signed lower bopunds. Element (i,j) of this matrix is:
%   1 if the lower bound contains a positive regulatory edge from gene i to
%   gene j, -1 if the lower bound contains a negative regulatory edge from
%   gene i to gene j, 0 if the lower bound contains no regulatory edge from
%   gene i to gene j
%acc=accessibility matrix without signs
%expt=list of multi KO experiments
%alpha= significance level for t-test
%mult_ko_data_files= list of files containing the data from multi KO
%   experiments. Note the order of experiments in expt must be the same as
%   the order of the data files in mult_ko_data_files.
%gu=updated signed upper bounds
%gl=updated signed lower bopunds


% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.


n=size(gu,1);
signs=sign(gu); %extract signs from upper bound
gu=abs(gu); %remove signs from upper bound
gl=abs(gl); %remove signs from lower bound
expts=array2string(expt,n); %convert to strings

num_exp=0;
ties=zeros(n); %to exclude tie votes from loop
while (1)
    sep_list1=sep_list_bound_cycle(gu,gl,acc); %calculate separatoids S1
    edges1=sep_list1(:,1:2);
    separatoids1=array2string(sep_list1(:,3:end),n);
    
    sep_list2=sep_list_bound_cycle_bu(gu,gl,acc); %calculate separatoids S2
    edges2=sep_list2(:,1:2);
    separatoids2=array2string(sep_list2(:,3:end),n);
    
    sep_list3=sep_list_bound_cycle_acc(gu,gl,acc); %calculate separatoids S3
    edges3=sep_list3(:,1:2);
    separatoids3=array2string(sep_list3(:,3:end),n);
    
    total_seps=size(sep_list1,1)+size(sep_list2,1)+size(sep_list3,1);
    test_tables=zeros(total_seps,4);
    k=1;
    
    for j=1:size(separatoids1,1)
        sep_check=check_subset(expts,separatoids1(j,:));
        row_i=edges1(j,1);
        row_j=edges1(j,2);
        if nnz(sep_check)>0 && ties(row_i,row_j)==0
            for ll=1:size(sep_check,1)
                ko_sep=expts(sep_check(ll),:);
                if ko_sep(row_j)==0 &&  ko_sep(row_i)==0
                    ko_row=ko_sep;
                    ko_row(row_i)=1;
                    if ~isequal(ko_row,ko_sep) && (find(ko_row-ko_sep)==row_i)
                        row_check=check_equal_row(expts,ko_row);
                        for mm=1:size(row_check,1)
                            test_tables(k,1:4)=[edges1(j,1:2),sep_check(ll),row_check(mm)];
                            k=k+1;
                        end
                    end
                end
            end
        end
    end
    
    
    
    for j=1:size(separatoids2,1)
        sep_check=check_subset(expts,separatoids2(j,:));
        row_i=edges2(j,1);
        row_j=edges2(j,2);
        if nnz(sep_check)>0 && ties(row_i,row_j)==0
            for ll=1:size(sep_check,1)
                ko_sep=expts(sep_check(ll),:);
                if ko_sep(row_j)==0 &&  ko_sep(row_i)==0
                    ko_sep=expts(sep_check(ll),:);
                    ko_row=ko_sep;
                    ko_row(row_i)=1;
                    if ~isequal(ko_row,ko_sep) && (find(ko_row-ko_sep)==row_i)
                        row_check=check_equal_row(expts,ko_row);
                        for mm=1:size(row_check,1)
                            test_tables(k,1:4)=[edges2(j,1:2),sep_check(ll),row_check(mm)];
                            k=k+1;
                        end
                    end
                end
            end
        end
    end
    
    
    
    for j=1:size(separatoids3,1)
        sep_check=check_subset(expts,separatoids3(j,:));
        row_i=edges3(j,1);
        row_j=edges3(j,2);
        if nnz(sep_check)>0 && ties(row_i,row_j)==0
            for ll=1:size(sep_check,1)
                ko_sep=expts(sep_check(ll),:);
                if ko_sep(row_j)==0 &&  ko_sep(row_i)==0
                    
                    ko_row=ko_sep;
                    ko_row(row_i)=1;
                    if ~isequal(ko_row,ko_sep) && (find(ko_row-ko_sep)==row_i)
                        row_check=check_equal_row(expts,ko_row);
                        for mm=1:size(row_check,1)
                            test_tables(k,1:4)=[edges3(j,1:2),sep_check(ll),row_check(mm)];
                            k=k+1;
                        end
                    end
                end
            end
        end
    end
    
    
    
    test_tables=unique(test_tables,'rows'); %list which edges are testable by which experiments
    
    % test_tables2=array2sets(test_tables);
    
    test_tables2=setdiff(unique(test_tables(:,3:4)),0);
    if isempty(test_tables2) 
        break; %stop loop if there are no edges verifiable by the given set of experiments
    end
    used_kos=zeros(length(test_tables2),n);
    k=1;
    for ll= 1:size(test_tables2,1)
        mm=test_tables2(ll);
        used_kos(k,:)=expts(mm,:);
        k=k+1;
    end
    used_kos=unique(used_kos,'rows');
    ko_exp=sum(used_kos,2);
    num_exp=num_exp+nnz(ko_exp>1);

    
    
    check_pos=zeros(n); %intialize positive votes
    check_neg=zeros(n); %intialize negative votes
    check_zero=zeros(n); %initialize votes againts existence
    check_one=zeros(n);  %initialize votes for existence
    
    for ll=2:size(test_tables,1)
        i=test_tables(ll,1);
        j=test_tables(ll,2);
        
        exp1=test_tables(ll,3);
        exp2=test_tables(ll,4);
        
        exp1_file=mult_ko_data_files{1}{exp1}; %locate the file containing the data from expt1        
        dat=importdata(exp1_file,'\t'); %read exp1 data
        data1=dat.data;
        x=data1(:,j); %expression level of gene j in exp1
        
        exp2_file=mult_ko_data_files{1}{exp2}; %locate the file containing the data from expt2
        dat=importdata(exp2_file,'\t'); %read exp2 data
        data2=dat.data;
        y=data2(:,j); %expression level of gene j in exp2        
       
       

        check=ttest2(x,y,alpha);
        if check==1
            check_one(i,j)=check_one(i,j)+1;
            if mean(x)>mean(y)
                check_pos(i,j)=check_pos(i,j)+1;
            elseif mean(y)>mean(x)
                check_neg(i,j)=check_neg(i,j)+1;
            end
        elseif check==0
            check_zero(i,j)=check_zero(i,j)+1;
        end
    end
    
    for i=1:n
        for j=1:n
            if gu(i,j)~=gl(i,j)
                if check_one(i,j)>check_zero(i,j)
                    gl(i,j)=1;
                    if check_pos(i,j)>check_neg(i,j)
                        signs(i,j)=1;
                    elseif check_pos(i,j)<check_neg(i,j)
                        signs(i,j)=-1;
                    end
                elseif  check_one(i,j)<check_zero(i,j)
                    gu(i,j)=0;
                elseif check_one(i,j)~=0 && check_one(i,j)==check_zero(i,j) %to avoid setting untested edges as tie edges
                    ties(i,j)=1;
                end
                
            end
        end
    end
    
end

gu=signs.*gu; %update signs
gl=signs.*gl; %update signs
