function [z_matrix,gu]=trace_gu(data_matrix,z_threshold,z_cutoff)

%This function estimates the upper bound  from differential
%gene expression data. 
%Inputs:
% data_matrix= knockout expression data formatted as follwing:
%   columns represent genes and the rows represent KO experiments. row
%   number k contains the expression level of the genes when gene number k
%   is knocked out
%z_threshold= threshold to check whether gene expression is significant or not
%z_cutoff= cutoff value for the consideration in calculating z score
%Outputs
% z_matrix= raw matrix of z -scores 
% gu= estimated upper bound. Element (i,j) of this matrix is:
%   1 if the upper bound contains a positive regulatory edge from gene i to
%   gene j, -1 if the upper bound contains a negative regulatory edge from
%   gene i to gene j, 0 if the upper bound contains no regulatory edge from
%   gene i to gene j




% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.



num_it=size(data_matrix,1);
n=size(data_matrix,2);
num_replicate=size(data_matrix,3);
z_matrix=zeros(num_it,n,num_replicate);
for rep=1:num_replicate
    
    data=data_matrix(:,:,rep);
    for i=1:num_it
        data_i=data(:,i);
        
        mu_i=mean(data_i);
        sigma_i=std(data_i);
        
        %%% Exclude outlyers %%%
            data_ii=data_i;
            data_ii(abs(data_ii-mu_i)>z_cutoff*sigma_i)=[];
            mu_i=mean(data_ii);
            sigma_i=std(data_ii);
        %%% Exclude outlyers %%%
        
        
        for j=1:num_it            
            if sigma_i~=0
                zval=(data_i(j)-mu_i)/sigma_i;
            elseif sigma_i==0
                zval=0;
            end
            z_matrix(j,i,rep)=zval;
        end
    end
end
z_matrix=(sum(z_matrix,3))/num_replicate;
z_matrix=remove_diagonal(z_matrix);
gu=(abs(z_matrix)>=z_threshold).*(-sign(z_matrix));