function corr_ko = conditional_correlation_ko(ko_data)

%This function calculates correlation matrix
%Inputs:
%ko_data= a matrix containing gene expression levels where element (i,j)
%represents expression level of gene j when gene i is knocked out.
%outputs:
%corr_ko=conditional correlation

% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.


n = size(ko_data,2); %number of genes
corr_ko = zeros(n); %initialize with all zero

    for k = 1 : n
        data = [mean(ko_data); ko_data]; 
        data(k+1,:) = []; %remove the data where gene k has been KO
        corr_ko(:,k) = corr(data,data(:,k));
    end



corr_ko(isnan(corr_ko)) = 0; %replace NanN with 0

