function b=remove_diagonal(a)
% This function removes the diagonal of the input matrix  and replace it
% with zeros.


% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.

for i=1:size(a,1)
    a(i,i)=0;
end
b=a;
end