function acc = adj2acc(adj)
%This function calculates the transitive closure of a graph provided as a
%input in form of an adjacency matrix (adj). The adjacency matrix is a
%square matrix by definition.



% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.

if (size(adj,1)==size(adj,2))
    n=length(adj);
    adj=abs(adj); %accessibility matrix requires the absolute value of the adj matrix
else
    error('The input must be a square matrix');
end

dummy = expm(single(full(adj))) - eye(n);
acc = (dummy>0);
acc(acc<=0)=0;
end