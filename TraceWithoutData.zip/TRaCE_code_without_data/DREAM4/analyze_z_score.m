function [z_matrix,acc_z]=analyze_z_score(data_matrix,z_threshold,z_cutoff)

%This function estimates the accessibility matrix  from differential
%gene expression data. It uses a modified version z-score calculation for 
%differential expression analysis. 
%Inputs
% data_matrix= wildtype and knockout expression data formatted as in the
% output from GeneNetWeaver (gnw.sourceforge.net)
% z_threshold= threshold to check whether gene expression is significant or
% not
% z_cutoff= cutoff value for the consideration in calculating z score
% Outputs
% z_matrix= raw matrix of z -scores
% acc_z= estimated accessibility matrix


% Last Update 20.05.2014


% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.



num_it=size(data_matrix,1); 
n=size(data_matrix,2);
num_replicate=size(data_matrix,3);
z_matrix=zeros(num_it,n,num_replicate);
for rep=1:num_replicate
    
    data=data_matrix(:,:,rep);
    for i=1:num_it
        data_i=data(:,i);
        
        mu_i=mean(data_i);
        sigma_i=std(data_i);
        
        %%% Exclude outlyers %%%
            data_ii=data_i;
            data_ii(abs(data_ii-mu_i)>z_cutoff*sigma_i)=[];
            mu_i=mean(data_ii);
            sigma_i=std(data_ii);
        %%% Exclude outlyers %%%
        
        
        for j=1:num_it            
            if sigma_i~=0
                zval=(data_i(j)-mu_i)/sigma_i;
            elseif sigma_i==0
                zval=0;
            end
            z_matrix(j,i,rep)=zval;
        end
    end
end
z_matrix=abs(sum(z_matrix,3))/num_replicate;
z_matrix=remove_diagonal(z_matrix);
acc_z=((z_matrix)>=z_threshold);