function [Kno_TR_Stack,Kno_TC_Stack,Kno_TC_Stack_TC, Kno_Adj_Stack,...
    Kno_Adj_Stack2] =acc_format(ko_acc_z_matrices,acc_z,ko)

% [Kno_TR_Stack,Kno_TC_Stack,Kno_TC_Stack_TC, Kno_Adj_Stack,...
%    Kno_Adj_Stack2,ko]   = acc_format(ko_acc_z_matrices,acc_z)
%
% formats the accessibility matrices estimated from z-scores into input
% arguments for TRaCE. The inputs are the following:
% ko_acc_z_matrices :  stack of KO accessiblity matrices
% acc_z : wildtype (G_O) accessiblity matrix
% ko: list of the knockouts in the same order as the accessibility matrices
% in Kno_TC_Stack
% Outputs: 
% Kno_TR_Stack: stack of the contrex of KO and G_O accessibility matrices
% Kno_TC_Stack: stack of KO and G_O accessibility matrices
% Kno_TC_Stack_TC: stack of the transitive closure of KO and G_O 
%   accessibility matrices 
% Kno_Adj_Stack: stack of adjacency matrices estimated from Kno_TR_Stack
% Kno_Adj_Stack2: stack of adjacency matrices estimated from Kno_TC_Stack

% Last Update 20.05.2014

% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or upto date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.



NUM_ELEM=size(ko_acc_z_matrices,1);

num_exp=length(ko);


Kno_Adj_Stack=zeros(NUM_ELEM,NUM_ELEM,num_exp,'int16');
Kno_TR_Stack=zeros(NUM_ELEM,NUM_ELEM,num_exp,'int16');
%Initialize Three Dimensional Array to stack Knckout Accesibility
Kno_TC_Stack=ones(NUM_ELEM,NUM_ELEM,num_exp,'int16'); 
       %consisting of All ones
Kno_TC_Stack_TC=ones(NUM_ELEM,NUM_ELEM,num_exp,'int16'); 
          %consisting of All ones

%Initialize Three Dimensional Array to stack Adjacency Deduced from Knckout
Kno_Adj_Stack2=zeros(NUM_ELEM,NUM_ELEM,num_exp,'int16'); 
                 %consisting of All zeroes
Kno_Adj_Stack2_TC=zeros(NUM_ELEM,NUM_ELEM,num_exp,'int16');
                  %consisting of All zeroes

for i=1:num_exp

    
    %Use G^t for lower bound
    lKno=ko(i); %the knocked out gene number
    if lKno==0
        Acc1=acc_z;
    else
        Acc1=ko_acc_z_matrices(:,:,i-1);
    end
    Acc_TC=adj2acc(Acc1); %transitive closure
    Acc_TR=contrex(Acc_TC+0); 
          %transitive reduction of the transitive closure
    Kno_TR_Stack(:,:,i)=Acc_TR; %stack the TR
    
    if (i==1)
        Kno_Adj_Stack(:,:,i)=boolean(int16(Acc_TR));
    else
        Kno_Adj_Stack(:,:,i)=boolean(int16(Acc_TR) ...
            +int16(Kno_Adj_Stack(:,:,i-1)));
    end
    
    
    %Use G^T for upper bound
    Kno_TC_Stack(:,:,i)= Acc1;
    Kno_TC_Stack_TC(:,:,i)= Acc_TC;
    
    if (lKno==0)
        Acc_Wt= Kno_TC_Stack(:,:,i); 
         % The first acc matrix in the input must be the WT(G_O)
        Kno_Adj_Stack2(:,:,i)=Acc_Wt;
        Kno_Adj_Stack2_TC(:,:,i)=Kno_TC_Stack_TC(:,:,i);
    else
        %Matrix to mask (lKno,lKno)
        mask=zeros(NUM_ELEM,NUM_ELEM);
        mask(:,lKno)=1;%Mask row
        mask(lKno,:)=1;%Mask coulms
        Kno_Adj_Stack2(:,:,i)=Acc_Wt.*(Kno_TC_Stack(:,:,i)+int16(mask));
        Kno_Adj_Stack2_TC(:,:,i)=Acc_Wt.*(Kno_TC_Stack_TC(:,:,i)...
            +int16(mask));
    end
end