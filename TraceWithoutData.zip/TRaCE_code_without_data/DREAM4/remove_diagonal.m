function b=remove_diagonal(a)
% This functional removes the diagonal of the input matrix  and replaces it
% with zeros.

% Last Update 20.05.2014

for i=1:size(a,1)
    a(i,i)=0;
end
b=a;
end