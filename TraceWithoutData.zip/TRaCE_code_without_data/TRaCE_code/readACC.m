function [Kno_TR_Stack,Kno_TC_Stack,Kno_TC_Stack_TC, Kno_Adj_Stack,...
    Kno_Adj_Stack2,ko]   = readACC(NUM_ELEM,INPUT_ACC,DESC)
% [Kno_TR_Stack,Kno_TC_Stack,Kno_TC_Stack_TC, Kno_Adj_Stack,...
%    Kno_Adj_Stack2,ko]   = readACC(NUM_ELEM,INPUT_ACC,DESC)
% reads accessibility matrices from a specified file, and converts the data
% into input arguments for TRaCE.The inputs are the following:
% NUM_ELEM :  number of genes
% INPUT_ACC : the name of the file containing the accessibility list 
% DESC : the name of the file containing description of the input
% accessibility list
% Outputs:
% Kno_TR_Stack: stack of the contrex of KO and G_O accessibility matrices
% Kno_TC_Stack: stack of KO and G_O accessibility matrices
% Kno_TC_Stack_TC: stack of the transitive closure of KO and G_O 
%   accessibility matrices 
% Kno_Adj_Stack: stack of adjacency matrices estimated from Kno_TR_Stack
% Kno_Adj_Stack2: stack of adjacency matrices estimated from Kno_TC_Stack
% ko: list of the knockouts in the same order as the accessibility matrices
% in Kno_TC_Stack
%
% Creation of the input accessibility file (INPUT_ACC): The list contains
% the accessibility data from  the full and any knock-out gene regulatory
% networks. Each line shows three numbers (comma separated). The first two
% numbers (i, j) correspond to the index of genes, which should be
% interpreted such that gene j is accessible from gene i. The last number
% should always be written as 1 (following the sparse matrix formatting of
% MATLAB). The segmentation of the list into different input accessibility
% matrices is specified in the DESC file. The minimum input is the
% accessibility  of the full network, which must be given at the top of the
% file. Below is an example of the file content:
%
% gene_1,gene_2,1
% ......
% gene_i,gene_j,1
% ........
%
% Creation of the description file (DESC): Each row contains at least two
% numbers (comma separated). The first number corresponds to the line
% number in the INPUT_ACC file, indicating the start of a separate
% accessibility list. The subsequent number(s) corresponds to the indices
% of genes knocked out from the network. The first row is always (1, 0),
% indicating the accessibility list of the full network, which is always
% provided at the beginning of the INPUT_ACC file (see above). Below is an
% example of the file content:
%
% 1, 0
% Line_2, KO2
% .......
% Line_i,KOi
% .........

% Last Update 19.05.2014
%
% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or up to date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.


%% Read and Process Accessibility Matrix of the wild type and KO
ko=DESC(:,2); %separate the list of ko
line_numbers=DESC(:,1); %separate the list of line numbers
num_exp=size(ko,1); %number of accessibility matrices



Kno_Adj_Stack=zeros(NUM_ELEM,NUM_ELEM,num_exp,'int16');
Kno_TR_Stack=zeros(NUM_ELEM,NUM_ELEM,num_exp,'int16');
%Initialize Three Dimensional Array to stack Knckout Accesibility
Kno_TC_Stack=ones(NUM_ELEM,NUM_ELEM,num_exp,'int16'); 
           %consisting of All ones
Kno_TC_Stack_TC=ones(NUM_ELEM,NUM_ELEM,num_exp,'int16');
                       %consisting of All ones

%Initialize Three Dimensional Array to stack Adjacency Deduced from Knckout
Kno_Adj_Stack2=zeros(NUM_ELEM,NUM_ELEM,num_exp,'int16');
                                        %consisting of All zeroes
Kno_Adj_Stack2_TC=zeros(NUM_ELEM,NUM_ELEM,num_exp,'int16'); 
                           %consisting of All zeroes



for i=1:num_exp
    if i<num_exp
        data_dump=INPUT_ACC(line_numbers(i):line_numbers(i+1)-1,:); 
                               %read required lines from the sparse matrix
    else
        data_dump=INPUT_ACC(line_numbers(i):end,:); 
                    %read required lines from the sparse matrix
    end
    Acc2=spconvert(data_dump); %convert to full matrix
    
    row=size(Acc2,1); %Find the size of the converted full matrix
    column=size(Acc2,2);  %Find the size of the converted full matrix
    Acc1=zeros(NUM_ELEM);
    Acc1(1:row,1:column)=Acc2; 
              %Make a padded accessibility matrix of the appropriate size
    
    %Use G^t for lower bound
    lKno=ko(i); %the knocked out gene number
    Acc_TC=adj2acc(Acc1); %transitive closure
    Acc_TR=contrex(Acc_TC+0); 
        %transitive reduction of the transitive closure
    Kno_TR_Stack(:,:,i)=Acc_TR; %stack the TR
    
    if (i==1)
        Kno_Adj_Stack(:,:,i)=boolean(int16(Acc_TR));
    else
        Kno_Adj_Stack(:,:,i)=boolean(int16(Acc_TR) ...
            +int16(Kno_Adj_Stack(:,:,i-1)));
    end
    
    
    %Use G^T for upper bound
    Kno_TC_Stack(:,:,i)= Acc1;
    Kno_TC_Stack_TC(:,:,i)= Acc_TC;
    
    if (lKno==0)
        Acc_Wt= Kno_TC_Stack(:,:,i); 
            % The first acc matrix in the input must be the WT
        Kno_Adj_Stack2(:,:,i)=Acc_Wt;
        Kno_Adj_Stack2_TC(:,:,i)=Kno_TC_Stack_TC(:,:,i);
    else
        %Matrix to mask (lKno,lKno)
        mask=zeros(NUM_ELEM,NUM_ELEM);
        mask(:,lKno)=1;%Mask row
        mask(lKno,:)=1;%Mask coulms
        Kno_Adj_Stack2(:,:,i)=Acc_Wt.*(Kno_TC_Stack(:,:,i)+int16(mask));
        Kno_Adj_Stack2_TC(:,:,i)=...
            Acc_Wt.*(Kno_TC_Stack_TC(:,:,i)+int16(mask));
    end
end

