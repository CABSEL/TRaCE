function [GL,GU]=trace(Kno_TR_Stack,Kno_TC_Stack,Kno_TC_Stack_TC,...
    Kno_Adj_Stack,Kno_Adj_Stack2,ko,THRESHOLD,ERROR)

% [GL,GU] = trace(NUM_ELEM,INPUT_ACC,DESC,THRESHOLD,ERROR)
% Returns the upper and lower bounds from input arguments obtained from
% readACC or acc_format
% Inputs:
% Kno_TR_Stack: stack of the contrex of KO and G_O accessibility matrices
% Kno_TC_Stack: stack of KO and G_O accessibility matrices
% Kno_TC_Stack_TC: stack of the transitive closure of KO and G_O 
%   accessibility matrices 
% Kno_Adj_Stack: stack of adjacency matrices estimated from Kno_TR_Stack
% Kno_Adj_Stack2:  stack of adjacency matrices estimated from Kno_TC_Stack
% ko: list of the knockouts in the same order as the accessibility matrices
% in Kno_TC_Stack
% THRESHOLD : threshold value for preprocessing step
% ERROR : set to 0 for error-free input, otherwise set to 1.
% Outputs:
% GL: estimated lower bound of the network
% GU: estimated upper bound of the network
%
%Last Update 20.05.2014
%
% Program written by S.M. Minhaz Ud-Dean. (minhazuddean@gmail.com) The
% author accepts no liability for the quality of the information provided
% or for it being correct, complete or up to date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.




if (ERROR==0)
    %OK
elseif (ERROR==1)
    %OK
else
    error(strcat('ERROR must be set. Set it to 1 if the accessibility',...
        'matrices are erroneous, otherwise set it to 0.'));
end

num_exp=size(Kno_Adj_Stack2,3);
NUM_ELEM=size(Kno_TR_Stack,1);
%%  Error free Reconstruction of Network
if (ERROR==0)
    
    
    Adj_estim=ones(NUM_ELEM,NUM_ELEM,'int16');
    
    
    for l=1:num_exp
        
        
        Adj_estim=Adj_estim.*Kno_Adj_Stack2(:,:,l);
        
    end
    
    GU=double(Adj_estim);
    GL=double(Kno_Adj_Stack(:,:,num_exp));
    return
end

%% =======================================%%
%Error Correction for upper bound from erroneous
%measurements G^m

Acc_Wt_Revised=sum(Kno_TC_Stack,3);
Acc_Wt_Revised(Acc_Wt_Revised<(num_exp*THRESHOLD))=0; 
         %Conversion to binary matrix %tweak %m2
Acc_Wt_Revised(Acc_Wt_Revised>=(num_exp*THRESHOLD))=1; 
       %Conversion to binary matrix %tweak
revised_upperbound=int16(Acc_Wt_Revised);

corrected_lower_bound=int16(contrex(Acc_Wt_Revised)); %initialize with  TR of revised WT

for i_exp=2:num_exp % i_exp=1 for wildtype
    i=ko(i_exp); %find gene number
    mask_testable=int16(Acc_Wt_Revised(:,i)*Acc_Wt_Revised(i,:));
      %Find the edges testable by ith knockout
    mask_hide_ko=ones(NUM_ELEM,'int16'); 
     %Hiding knockouts. First allow everything to change
    mask_hide_ko(i,:)=0; 
     %Then block the connections from the ith gene to change
    mask_hide_ko(:,i)=0; 
     % Then block the connections to the ith gene to change
    mask_allow_change=int16(mask_testable.*mask_hide_ko); 
     %Finally only allow the testable connections neither
     % toward nor from the ith gene to change
    revised_upperbound=revised_upperbound.*(ones(NUM_ELEM,'int16')...
        -(mask_allow_change-mask_allow_change.*Kno_TC_Stack(:,:,i_exp))); 
             %See justification below
    %justification: mask.*c sets everything other than the unchanged
    %testable edges to zero. Now mask-mask.*c selects the testable
    %edges which changed by this knockout. Then ones(num_elem)-
    %(mask-mask.*c) makes a new mask where everything other than the
    %chnaged edges are one. Later multiplying it with the bound removes
    %only the changed edges from the bound.
    corrected_lower_bound=int16(boolean(corrected_lower_bound+...
        Kno_TR_Stack(:,:,i_exp).*mask_testable));
end

corrected_upper_bound=revised_upperbound;
corrected_upper_bound(corrected_upper_bound>=1)=1;
   %Conversion to binary matrix 
corrected_upper_bound(corrected_upper_bound<=0)=0;
   %Conversion to binary matrix 


%Find inconsistent edges
% corrected_lower_bound=full(corrected_lower_bound);
errors_found=corrected_lower_bound-corrected_upper_bound;
errors_found(errors_found<0)=0;


%Error Correction for lower bound
for i=1:NUM_ELEM
    for j=1:NUM_ELEM
        if (errors_found(i,j)==1)
            num_against=0;
            num_favor=0;
            for k=1:num_exp
                if (Kno_TR_Stack(i,j,k)==1 && Kno_TC_Stack(i,j,k)==1)
                    num_favor=num_favor+1;
                elseif (Kno_TR_Stack(i,j,k)==0 && Kno_TC_Stack(i,j,k)==0)
                    num_against=num_against+1;
                end
            end
            if num_favor>= num_against
                corrected_upper_bound(i,j)=1;
            elseif num_favor< num_against
                corrected_lower_bound(i,j)=0;
            end
        end
    end
end

%% =======================================%%

%Error Correction for upper bound from TC of erroneous
%measurements TC(G^m)

Acc_Wt_Revised=sum(Kno_TC_Stack_TC,3);
Acc_Wt_Revised(Acc_Wt_Revised<(num_exp*THRESHOLD))=0; 
           %Conversion to binary matrix 
Acc_Wt_Revised(Acc_Wt_Revised>=(num_exp*THRESHOLD))=1; 
                 %Conversion to binary matrix 
revised_upperbound=int16(Acc_Wt_Revised);


for i_exp=2:num_exp  %i_exp=1 for wildtype
    i=ko(i_exp);
    mask_testable=int16(Acc_Wt_Revised(:,i)*Acc_Wt_Revised(i,:)); 
                %Find the edges testable by ith knockout
    mask_hide_ko=ones(NUM_ELEM,'int16'); 
              %Hiding knockouts. First allow everything to change
    mask_hide_ko(i,:)=0; 
            %Then block the connections from the ith gene to change
    mask_hide_ko(:,i)=0;
                   % Then block the connections to the ith gene to change
    mask_allow_change=int16(mask_testable.*mask_hide_ko); 
    %Finally only allow the testable connections neither toward nor
    % from the ith gene to change
    revised_upperbound=revised_upperbound.*(ones(NUM_ELEM,'int16')-...
        (mask_allow_change-mask_allow_change.*Kno_TC_Stack_TC(:,:,i_exp)));
                            %See justification below
    %justification: mask.*c sets everything other than the unchanged
    %testable edges to zero. Now mask-mask.*c selects the testable
    %edges which changed by this knockout. Then ones(num_elem)-
    %(mask-mask.*c) makes a new mask where everything other than the
    %chnaged edges are one. Later multiplying it with the bound removes
    %only the changed edges from the bound.
    
end

corrected_upper_bound=revised_upperbound;
corrected_upper_bound(corrected_upper_bound>=1)=1; 
                %Conversion to binary matrix 
corrected_upper_bound(corrected_upper_bound<=0)=0; 
                   %Conversion to binary matrix 



%Find inconsistent edges

errors_found=corrected_lower_bound-corrected_upper_bound;
errors_found(errors_found<0)=0;

%Error Correction for lower bound


for i=1:NUM_ELEM
    for j=1:NUM_ELEM
        if (errors_found(i,j)==1)
            num_against=0;
            num_favor=0;
            for k=1:num_exp
               if (Kno_TR_Stack(i,j,k)==1 && Kno_TC_Stack_TC(i,j,k)==1)
                    num_favor=num_favor+1;
               elseif (Kno_TR_Stack(i,j,k)==0 && Kno_TC_Stack_TC(i,j,k)==0)
                    num_against=num_against+1;
               end
            end
            if num_favor>= num_against
                corrected_upper_bound(i,j)=1;
            elseif num_favor< num_against
                corrected_lower_bound(i,j)=0;
            end
        end
    end
end
if (ERROR==1)
    GL=corrected_lower_bound;
    GU=corrected_upper_bound;
end
GL=double(GL);
GU=double(GU);
end